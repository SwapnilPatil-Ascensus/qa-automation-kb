# Mobile Microservices API Automation — Cursor Autopilot Pack

## Purpose

This package is intended to be extracted into the root of the existing API Automation repository.

The package gives Cursor one controlled master runner. Cursor will inspect the existing framework, document the findings, design the safest additive structure, create the Unite Enrollment pilot skeleton, validate a non-network bootstrap test, inspect the legacy Unite Enrollment repository, propose and migrate a small vertical slice where safe, and create a local smoke/regression switch.

CI/CD pipeline integration is intentionally excluded from this package.

## How to Use

1. Extract this folder into the root of the existing API Automation repository.
2. Open the API Automation repository in Cursor.
3. Copy and paste the contents of:
   `COPY_PASTE_THIS_INTO_CURSOR.txt`
4. Let Cursor follow:
   `START_HERE_CURSOR_RUNNER.md`

## What Cursor Must Not Do

- Do not modify application development repositories.
- Do not change existing working behavior.
- Do not upgrade dependency or plugin versions.
- Do not add CI/CD pipeline integration.
- Do not migrate the full Enrollment suite in one uncontrolled batch.
- Do not commit credentials, tokens, URLs containing secrets, or passwords.
- Do not automatically commit or push code.

## Expected Outputs

Cursor should create documentation under:

```text
docs/mobile-microservices/
```

Cursor should create implementation code only after discovery and architecture review inside the same autonomous run, provided no high-risk condition is detected.

## User Inputs

Cursor should auto-detect the current API Automation repository root.

The legacy Unite Enrollment source repository path may not be known. If Cursor cannot detect it, Cursor must pause once and ask for:

```text
LEGACY_UNITE_ENROLLMENT_REPO=<absolute local path>
DEFAULT_LOCAL_ENV=<qc4 | stage1 | stage2 | stage5 | another valid local target>
```

The default environment is used only for local validation after the non-network bootstrap stage.
