# Project Context

## Current State

The organization has existing Unite-related API automation inside application development repositories. These repositories contain application code plus test assets such as:

- Cucumber feature files
- Java step definitions
- REST Assured logic
- request and response models
- environment configurations
- SQL
- test data
- supporting utility methods
- possible Postman collections

The existing automation is valuable as a baseline, but it is not the desired long-term location. It may be stale, out of sync, or coupled to application code.

## Existing Centralized Framework

There is an existing API Automation repository with:

- a `universal` area containing working modules
- a `json-api` or similar area containing reusable libraries
- environment-specific test-data/config patterns
- SQL usage
- suite or runner patterns
- existing REST Assured-based execution

Cursor must inspect the actual repository and align with its conventions.

## Target

Create a separate Mobile Microservices API Automation area parallel to `universal`.

Tentative direction:

```text
api-automation/
├── json-api/
├── universal/
└── mobile-microservices/
    └── unite-enrollment/
```

The physical structure must be adapted to the repository’s real Maven/build conventions.

## Priority

1. Unite Enrollment
2. Unite Mobile 1
3. Unite Mobile 2

Only Unite Enrollment is implemented in this run.
