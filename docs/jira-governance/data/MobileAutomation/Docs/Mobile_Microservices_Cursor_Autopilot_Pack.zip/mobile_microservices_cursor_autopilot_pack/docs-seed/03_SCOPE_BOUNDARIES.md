# Scope Boundaries

## In Scope

- repository inspection
- reuse assessment
- architecture documentation
- additive skeleton
- non-network bootstrap test
- Unite Enrollment legacy discovery
- source-to-target mapping
- vertical-slice migration where safe
- local-only suite switch
- local execution documentation
- backlog of deferred shared-core improvements

## Out of Scope

- pipeline integration
- scheduled jobs
- Jenkins updates
- GitLab CI updates
- Azure DevOps updates
- notification setup
- dependency upgrades
- framework rewrites
- Mobile 1 implementation
- Mobile 2 implementation
- BrowserStack/Appium UI automation
