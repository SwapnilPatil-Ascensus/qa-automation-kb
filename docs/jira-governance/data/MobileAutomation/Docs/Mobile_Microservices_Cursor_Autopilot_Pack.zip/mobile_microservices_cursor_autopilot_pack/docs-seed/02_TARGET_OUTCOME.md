# Target Outcome

## First Meaningful Achievement

The first meaningful result is not merely a folder tree.

It is:

```text
A new Unite Enrollment pilot module exists inside the centralized API Automation
repository, compiles safely, runs a non-network bootstrap test, loads non-secret
configuration using the existing framework conventions, loads sample test data,
produces a report or test artifact, and does not disturb existing modules.
```

## Second Meaningful Achievement

When legacy contracts and environment inputs are clear:

```text
Three to five representative Unite Enrollment API scenarios are migrated
one-by-one into the new pilot module and can be run locally.
```

## Local Execution Requirement

Create a local-only execution switch that supports:

```text
bootstrap
smoke
regression
debug
```

The exact implementation must align with existing repository conventions.

Preferred user experience:

```powershell
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite smoke -Env qc4
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite regression -Env stage1
```

A shell equivalent may be added for non-Windows users:

```bash
./scripts/run-mobile-ms-local.sh --service unite-enrollment --suite smoke --env qc4
```

These scripts should map into the existing Maven/Cucumber execution mechanism. They must not introduce a second test framework.
