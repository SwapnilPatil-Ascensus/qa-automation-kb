# Blockers and Decisions Needed

| ID | Phase | Finding | Why Cursor stopped | Safest options | User or SME input needed |
|---|---|---|---|---|---|
