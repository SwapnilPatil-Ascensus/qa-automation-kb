# Reuse Decision Matrix

| Capability | Existing path | Existing consumers | Reuse unchanged? | Adapter needed? | New mobile-specific code needed? | Shared-core candidate? | Decision | Evidence |
|---|---|---|---:|---:|---:|---:|---|---|
