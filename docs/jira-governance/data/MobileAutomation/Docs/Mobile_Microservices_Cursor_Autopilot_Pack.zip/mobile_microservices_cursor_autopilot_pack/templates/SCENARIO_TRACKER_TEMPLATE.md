# Unite Enrollment Scenario Tracker

| ID | Feature path | Scenario | Tags | Endpoint | Method | Test data | SQL | Legacy dependency | Wave | Migration status | Local result | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
