# User Inputs Template

Copy this file to:

```text
inputs/USER_INPUTS.md
```

Fill values only when known.

```text
LEGACY_UNITE_ENROLLMENT_REPO=
DEFAULT_LOCAL_ENV=
```

Notes:
- `LEGACY_UNITE_ENROLLMENT_REPO` should be an absolute local path to the cloned legacy Enrollment application repository.
- `DEFAULT_LOCAL_ENV` should be a safe approved environment such as `qc4`, `stage1`, `stage2`, or `stage5`.
- Do not place credentials in this file.
