# Phase 4 — Vertical Slice and Local Regression Switch

## Part A — Select Vertical Slice

Choose 3–5 representative Enrollment scenarios.

Prefer scenarios that:
- matter to the business
- cover stable endpoints
- prove auth and environment config
- prove request construction
- prove response validation
- use manageable data
- minimize heavy SQL for the first wave
- minimize application-runtime coupling

Avoid selecting only trivial scenarios.

Create:

```text
docs/mobile-microservices/migration/enrollment/10-vertical-slice-proposal.md
docs/mobile-microservices/migration/enrollment/11-vertical-slice-implementation-plan.md
docs/mobile-microservices/migration/enrollment/12-dev-sme-question-list.md
```

## Part B — Migrate Safely

If contracts, credentials mechanism, environment, and expected behavior are clear, migrate scenarios one-by-one.

After each scenario:
1. compile
2. run targeted scenario
3. capture evidence
4. document blockers
5. proceed only if stable

Keep:
- Gherkin readable
- step definitions thin
- request logic in approved client/action structure
- large payloads outside feature files
- SQL outside Java where existing framework convention supports it

Create:

```text
docs/mobile-microservices/migration/enrollment/13-vertical-slice-status.md
docs/mobile-microservices/validation/04-enrollment-vertical-slice-evidence.md
```

## Part C — Local Suite Switch

Create a local-only smoke/regression switch aligned with the repository’s existing execution model.

Preferred interface:

```powershell
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite bootstrap -Env qc4
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite smoke -Env qc4
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite regression -Env stage1
./scripts/run-mobile-ms-local.ps1 -Service unite-enrollment -Suite debug -Env qc4 -Tags "@scenarioTag"
```

Add shell equivalent when practical:

```bash
./scripts/run-mobile-ms-local.sh --service unite-enrollment --suite smoke --env qc4
```

## Script Requirements

The script must:
- validate inputs
- support `bootstrap`, `smoke`, `regression`, and `debug`
- map suite names to existing Maven/Cucumber tags or profiles
- print the final Maven command
- avoid storing credentials
- fail clearly for unsupported service or suite
- remain local-only
- not modify pipeline files

## Documentation

Create:

```text
docs/mobile-microservices/local-execution/01-local-suite-switch.md
docs/mobile-microservices/local-execution/02-command-reference.md
docs/mobile-microservices/local-execution/03-troubleshooting.md
```

## Scope Restraint

Do not migrate all Enrollment scenarios automatically.

After vertical-slice success, document the remaining batches for later approval:

```text
docs/mobile-microservices/migration/enrollment/14-remaining-batch-plan.md
```
