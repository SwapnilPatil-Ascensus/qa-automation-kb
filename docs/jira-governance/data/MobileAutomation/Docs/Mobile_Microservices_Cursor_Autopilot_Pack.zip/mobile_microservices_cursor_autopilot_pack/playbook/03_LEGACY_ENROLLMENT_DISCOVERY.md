# Phase 3 — Read-Only Legacy Unite Enrollment Discovery

## Input

Cursor should try to find the legacy repository path from:
- workspace folders
- `inputs/USER_INPUTS.md`
- adjacent local folders
- previously generated docs

If not found, pause and ask once for:

```text
LEGACY_UNITE_ENROLLMENT_REPO=<absolute local path>
DEFAULT_LOCAL_ENV=<approved local target>
```

## Rule

The legacy application repository is read-only.

Do not modify it.

## Inspect

- features
- scenarios
- tags
- step definitions
- hooks
- runners
- request builders
- response assertions
- auth
- configs
- properties
- environment logic
- test data
- SQL
- DB utilities
- models
- Postman collections
- docs
- scripts
- application-code dependencies
- stale or legacy assumptions

## Create

```text
docs/mobile-microservices/migration/enrollment/01-legacy-asset-inventory.md
docs/mobile-microservices/migration/enrollment/02-scenario-inventory.md
docs/mobile-microservices/migration/enrollment/03-step-definition-map.md
docs/mobile-microservices/migration/enrollment/04-endpoint-auth-map.md
docs/mobile-microservices/migration/enrollment/05-testdata-sql-config-map.md
docs/mobile-microservices/migration/enrollment/06-application-dependency-map.md
docs/mobile-microservices/migration/enrollment/07-source-to-target-map.md
docs/mobile-microservices/migration/enrollment/08-risks-blockers-sme-questions.md
docs/mobile-microservices/migration/enrollment/09-postman-local-connectivity-checklist.md
```

## Categorize Each Scenario

| Category | Meaning |
|---|---|
| Wave 1 | vertical-slice candidate |
| Wave 2 | standard migration |
| Wave 3 | complex data, SQL, or dependency migration |
| Parked | obsolete, duplicate, unclear, or blocked |

## Scenario Inventory Columns

| ID | Feature path | Scenario | Tags | Endpoint | Method | Test data | SQL | Environment assumptions | App-code dependency | Status | Wave | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
