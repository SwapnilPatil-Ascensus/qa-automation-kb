# Phase 5 — Controlled Fix Loop and Stop Conditions

## Allowed Automatic Fix Loop

For changes isolated to the new Mobile Microservices area:

```text
Inspect failure
    ↓
Classify root cause
    ↓
Make smallest safe fix
    ↓
Compile
    ↓
Run targeted test
    ↓
Capture evidence
    ↓
Repeat up to 3 times
```

## Allowed Automatic Fixes

- package/import correction inside new module
- path correction inside new module
- test-resource loading correction
- script parameter correction
- wrapper/adapter adjustment inside new module
- assertion correction when expected behavior is documented
- Markdown documentation correction

## Do Not Auto-Fix

- shared-library behavior
- dependency versions
- Maven plugin versions
- root profiles beyond minimal approved registration
- existing module code
- application repo code
- auth mechanism
- endpoint contract
- database schema logic
- secrets
- pipeline files

## Stop Conditions

Stop and ask the user when:

1. Existing unrelated changes are present.
2. Existing tests fail before new changes.
3. Shared-core modification appears necessary.
4. Dependency or plugin upgrade appears necessary.
5. A real endpoint contract is unclear.
6. Auth or credential injection is unclear.
7. Environment access fails.
8. Legacy code depends on application runtime code and safe replacement is unclear.
9. SQL behavior is unclear.
10. More than three isolated repair attempts fail.
11. The expected response conflicts with actual API behavior.
12. Destructive or broad changes appear necessary.

## Blocker Documentation

Create or update:

```text
docs/mobile-microservices/execution/50-blockers-and-decisions-needed.md
```

Use:

| ID | Phase | Finding | Why Cursor stopped | Safest options | User or SME input needed |
|---|---|---|---|---|---|
