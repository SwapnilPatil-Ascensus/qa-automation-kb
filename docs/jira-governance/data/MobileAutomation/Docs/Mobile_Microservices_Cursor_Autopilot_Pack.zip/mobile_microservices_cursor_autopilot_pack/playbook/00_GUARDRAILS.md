# Phase 0 — Guardrails

## Required Behavior

Operate conservatively.

Use this reuse hierarchy:

```text
1. Reuse existing shared implementation unchanged
2. Add a Unite Enrollment wrapper or adapter
3. Add mobile-specific shared support only after repeated need is proven
4. Log shared-core enhancement ideas for later approval
```

## Required Backlog File

Create:

```text
docs/mobile-microservices/backlog/shared-core-improvement-backlog.md
```

Use this table:

| ID | Observation | Existing path | Proposed improvement | Why deferred | Potential consumers | Risk | Priority | Approval needed |
|---|---|---|---|---|---|---|---|---|

## Do Not

- change shared library behavior silently
- introduce a new testing framework
- create unnecessary abstraction layers
- put bulky request payloads directly into Gherkin unless the existing framework intentionally does so for a valid reason
- expose secrets in documentation or logs
