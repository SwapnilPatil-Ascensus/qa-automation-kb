# Phase 1 — Existing Repository Discovery and Repo-Aligned Architecture

## Goal

Inspect the existing API Automation repository and design the exact additive structure.

## Documentation-Only First

Create documentation before modifying implementation code.

Create:

```text
docs/mobile-microservices/discovery/01-repository-baseline.md
docs/mobile-microservices/discovery/02-build-topology.md
docs/mobile-microservices/discovery/03-shared-library-reuse-inventory.md
docs/mobile-microservices/discovery/04-existing-module-patterns.md
docs/mobile-microservices/discovery/05-config-testdata-sql-reporting-inventory.md
docs/mobile-microservices/discovery/06-risks-and-unknowns.md

docs/mobile-microservices/architecture/01-target-architecture.md
docs/mobile-microservices/architecture/02-proposed-folder-tree.md
docs/mobile-microservices/architecture/03-reuse-decision-matrix.md
docs/mobile-microservices/architecture/04-minimal-change-plan.md
docs/mobile-microservices/architecture/05-bootstrap-validation-plan.md
docs/mobile-microservices/architecture/06-mobile1-mobile2-scaling-plan.md
```

## Inspect

### Build Topology
- root `pom.xml`
- nested POMs
- aggregation vs inheritance
- dependency management
- plugin management
- Maven profiles
- Surefire / Failsafe
- JUnit / TestNG / Cucumber runner model
- report plugins
- module registration pattern

### Shared Capabilities
Inspect `json-api` and equivalent reusable code:
- request specs
- response specs
- auth
- config loading
- environment switching
- JSON loading
- POJO serialization
- SQL/database helpers
- logging
- filters
- hooks
- state/context
- assertions
- reporting
- exceptions

### Representative Existing Modules
Inspect representative modules under `universal`:
- folder tree
- package naming
- feature files
- step definitions
- runners
- tags
- test data
- SQL
- configs
- Maven commands
- report artifacts

## Reuse Matrix

Create:

| Capability | Existing path | Existing consumers | Reuse unchanged? | Adapter needed? | New mobile-specific code needed? | Shared-core candidate? | Decision | Evidence |
|---|---|---|---:|---:|---:|---:|---|---|

## Architecture Rule

Use the repository’s actual conventions.

The proposed logical area is:

```text
mobile-microservices/
└── unite-enrollment/
```

Do not force a generic structure if the existing framework uses a cleaner pattern.

## Minimal Existing-File Changes

Document every existing file that must be modified.

Prefer:
- one minimal root aggregator registration change, if required
- zero shared behavior changes

If more than that appears necessary, stop and explain.
